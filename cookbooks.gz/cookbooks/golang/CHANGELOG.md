# CHANGELOG for golang

This file is used to list changes made in each version of golang.

## 1.4.0:

* Add build action to LWRP
* Update default go version to 1.2.2
* Add autodetection the platform architecture
* Change package location to http://golang.org/dl/

## 1.3.0:

## 1.2.0:

## 1.1.0:

* Added package LWRP
* Configurable `gopath` & `gobin`

## 1.0.2:

* Lets users easily specify another install dir

## 1.0.1:

* Avoid extra unpacked copy of Go

## 1.0.0:

* Initial release of golang
